# Hostel Maintenance & Complaint Tracker

## Project Overview

The **Hostel Maintenance & Complaint Tracker** is a simple Java-based console application designed to help students report and track hostel maintenance problems.

Students can submit complaints related to electrical work, plumbing, cleaning, furniture, internet, room maintenance, and other hostel facilities. The system stores complaint details, assigns priority, updates complaint status, searches records, and provides a summary of complaints.

This project is developed as an academic project for the **Programming in Java** course and demonstrates basic Object-Oriented Programming, collections, file handling, input validation, and exception handling.

## Problem Statement

Hostel students may face maintenance issues such as damaged lights, water leakage, broken furniture, cleaning problems, or internet issues. When complaints are handled manually, it can be difficult to keep track of their status and priority.

This project provides a simple computerized system to record complaints and monitor their progress.

## Objectives

- To record hostel maintenance complaints digitally.
- To organize complaints by category and priority.
- To update the status of complaints.
- To search complaints using complaint ID or keyword.
- To delete incorrect complaint records.
- To display pending and resolved complaints.
- To provide complaint statistics.
- To demonstrate Java OOP and file handling concepts.

## Main Features

1. Submit a new complaint
2. View all complaints
3. Search complaints
4. Update complaint status
5. Delete a complaint
6. View pending complaints
7. View resolved complaints
8. View complaint summary
9. Save complaint data to a text file
10. Load previously saved complaints when the program starts

## Complaint Categories

- Electrical
- Plumbing
- Cleaning
- Furniture
- Internet
- Room Maintenance
- Other

## Complaint Status

- Submitted
- In Progress
- Resolved

## Priority

- Low
- Medium
- High

## Technologies Used

- Java
- Java Collections (`ArrayList`)
- File Handling (`BufferedReader`, `BufferedWriter`)
- Exception Handling
- Object-Oriented Programming
- VS Code / IntelliJ IDEA / Eclipse
- Git and GitHub

## Java Concepts Demonstrated

| Concept | Use in Project |
|---|---|
| Class & Object | Complaint, ComplaintManager, FileManager |
| Encapsulation | Private fields with getters/setters |
| Constructor | Creating complaint objects |
| ArrayList | Storing complaints |
| Methods | Separate operations such as add, search and update |
| Switch | Main menu |
| Loops | Menu and complaint display |
| Exception Handling | Invalid input and file errors |
| File Handling | Saving/loading complaints |
| String Handling | Searching complaint text |

## Project Structure

```text
Hostel-Maintenance-Complaint-Tracker/
│
├── README.md
├── .gitignore
│
├── src/
│   ├── Main.java
│   ├── Complaint.java
│   ├── ComplaintManager.java
│   ├── FileManager.java
│   └── InputValidator.java
│
├── data/
│   └── complaints.txt
│
├── docs/
│   ├── architecture.md
│   ├── class_design.md
│   └── requirements.md
│
├── diagrams/
│   ├── class_diagram.png
│   └── flowchart.png
│
├── screenshots/
│   └── (add screenshots of program output here)
│
└── report/
    └── Hostel_Maintenance_Project_Report.pdf
```

## How to Run

### Using VS Code

1. Install Java JDK 17 or later.
2. Open this project folder in VS Code.
3. Open the `src` folder in the terminal.
4. Compile the program:

```bash
javac *.java
```

5. Run:

```bash
java Main
```

### Using one command from the project root

On Windows PowerShell:

```powershell
javac src/*.java
java -cp src Main
```

On Windows Command Prompt:

```cmd
javac src\*.java
java -cp src Main
```

## Sample Menu

```text
========================================
     HOSTEL MAINTENANCE TRACKER
========================================
1. Submit Complaint
2. View All Complaints
3. Search Complaint
4. Update Complaint Status
5. Delete Complaint
6. View Pending Complaints
7. View Resolved Complaints
8. View Complaint Summary
9. Exit
```

## Data Storage

Complaint records are stored in:

```text
data/complaints.txt
```

The file is automatically created when the program saves data.

## Future Scope

- Login system for students and hostel staff
- GUI using Java Swing or JavaFX
- Database integration using JDBC
- Email or notification alerts
- Staff assignment for individual complaints
- Photo attachment for maintenance problems
- Web or mobile version

## Author

**Name:** Your Name  
**Registration Number:** Your Registration Number  
**Course:** Programming in Java

